package com.dao;

import com.model.Login;
import com.model.Registration;

//This interface is used for my User Registration functionality
public interface UserDao {
	
	public void registration(Registration reg);

}
