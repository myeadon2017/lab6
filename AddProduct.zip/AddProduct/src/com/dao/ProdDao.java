package com.dao;

import java.util.List;

import com.model.AddProduct;

//This interface is used for adding products functionality skeleton
public interface ProdDao {
	
	public void addProduct(AddProduct ap);

}
